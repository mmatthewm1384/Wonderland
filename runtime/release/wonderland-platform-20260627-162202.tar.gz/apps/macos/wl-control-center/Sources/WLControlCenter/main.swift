import SwiftUI
import Foundation
import AppKit

struct ReadyResponse: Decodable {
    let ready: Bool
    let status: String?
    let runtime_running: Bool?
    let services_ready: Int?
    let services_total: Int?
    let drifted: Int?
}

struct VersionResponse: Decodable {
    let platform: String?
    let version: String?
    let controller: String?
    let api: String?
    let schema: Int?
    let runtime: String?
    let git_revision: String?
}

struct PluginResponse: Decodable {
    let enabled: Bool?
    let count: Int?
    let plugins: [String]?
    let errors: [String]?
}

struct PlatformState: Decodable {
    let runtime: RuntimeState?
    let certification: Certification?
    let controller: ControllerState?
    let registry: RegistryState?
    let events: [PlatformEvent]?
}

struct RuntimeState: Decodable {
    let name: String?
    let running: Bool?
    let container_runtime: String?
}

struct Certification: Decodable {
    let status: String?
}

struct ControllerState: Decodable {
    let version: String?
    let api_version: String?
    let cycle_duration_seconds: Double?
}

struct RegistryState: Decodable {
    let resolved_services: ResolvedServices?
}

struct ResolvedServices: Decodable {
    let total: Int?
    let ready: Int?
    let drifted: Int?
    let services: [ResolvedService]?
}

struct ResolvedService: Decodable, Identifiable {
    var id: String { name }
    let name: String
    let desired: Bool?
    let running: Bool?
    let healthy: Bool?
    let ready: Bool?
    let status: String?
}

struct PlatformEvent: Decodable, Identifiable {
    var id: String { "\(ts)-\(type)" }
    let ts: Double
    let type: String
}

@MainActor
final class PlatformStore: ObservableObject {
    @Published var ready: ReadyResponse?
    @Published var version: VersionResponse?
    @Published var state: PlatformState?
    @Published var plugins: PluginResponse?
    @Published var error: String?

    private let baseURL = URL(string: "http://127.0.0.1:9105/api/v1")!

    func refresh() async {
        do {
            async let ready: ReadyResponse = get("ready")
            async let version: VersionResponse = get("version")
            async let state: PlatformState = get("state")
            async let plugins: PluginResponse = get("plugins")

            self.ready = try await ready
            self.version = try await version
            self.state = try await state
            self.plugins = try await plugins
            self.error = nil
        } catch {
            self.error = error.localizedDescription
        }
    }

    func get<T: Decodable>(_ path: String) async throws -> T {
        let url = baseURL.appendingPathComponent(path)
        let (data, response) = try await URLSession.shared.data(from: url)

        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw URLError(.badServerResponse)
        }

        return try JSONDecoder().decode(T.self, from: data)
    }

    func startPolling() {
        Task {
            while true {
                await refresh()
                try? await Task.sleep(nanoseconds: 5_000_000_000)
            }
        }
    }
}

@main
struct WLControlCenterApp: App {
    @StateObject private var store = PlatformStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .task {
                    await store.refresh()
                    store.startPolling()
                }
        }
    }
}

struct ContentView: View {
    @EnvironmentObject var store: PlatformStore

    var body: some View {
        NavigationSplitView {
            List {
                NavigationLink("Overview") { OverviewView() }
                NavigationLink("Services") { ServicesView() }
                NavigationLink("Events") { EventsView() }
                NavigationLink("Plugins") { PluginsView() }
                NavigationLink("Links") { LinksView() }
            }
            .navigationTitle("Wonderland")
        } detail: {
            OverviewView()
        }
        .frame(minWidth: 980, minHeight: 620)
    }
}

struct OverviewView: View {
    @EnvironmentObject var store: PlatformStore

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text("Platform Overview")
                    .font(.largeTitle.bold())
                    .foregroundStyle(.cyan)

                if let error = store.error {
                    Card(title: "API", value: "Unavailable", detail: error, good: false)
                }

                LazyVGrid(columns: [GridItem(.adaptive(minimum: 220))], spacing: 16) {
                    Card(
                        title: "Readiness",
                        value: store.ready?.ready == true ? "READY" : "NOT READY",
                        detail: store.ready?.status ?? "unknown",
                        good: store.ready?.ready == true
                    )

                    Card(
                        title: "Runtime",
                        value: store.ready?.runtime_running == true ? "RUNNING" : "DOWN",
                        detail: store.state?.runtime?.name ?? "unknown",
                        good: store.ready?.runtime_running == true
                    )

                    Card(
                        title: "Services",
                        value: "\(store.ready?.services_ready ?? 0)/\(store.ready?.services_total ?? 0)",
                        detail: "ready",
                        good: store.ready?.services_ready == store.ready?.services_total
                    )

                    Card(
                        title: "Drift",
                        value: "\(store.ready?.drifted ?? 0)",
                        detail: "drifted",
                        good: (store.ready?.drifted ?? 1) == 0
                    )

                    Card(
                        title: "Controller",
                        value: store.version?.controller ?? "unknown",
                        detail: "API \(store.version?.api ?? "unknown")",
                        good: true
                    )

                    Card(
                        title: "Cycle",
                        value: "\(store.state?.controller?.cycle_duration_seconds ?? 0)s",
                        detail: "last reconcile",
                        good: true
                    )
                }
            }
            .padding(24)
        }
    }
}

struct ServicesView: View {
    @EnvironmentObject var store: PlatformStore

    var services: [ResolvedService] {
        store.state?.registry?.resolved_services?.services ?? []
    }

    var body: some View {
        VStack(alignment: .leading) {
            Text("Services")
                .font(.largeTitle.bold())
                .foregroundStyle(.cyan)

            Table(services) {
                TableColumn("Service") { Text($0.name).monospaced() }
                TableColumn("Desired") { Badge($0.desired == true ? "YES" : "NO", good: $0.desired == true) }
                TableColumn("Running") { Badge($0.running == true ? "YES" : "NO", good: $0.running == true) }
                TableColumn("Healthy") { Badge($0.healthy == true ? "YES" : "NO", good: $0.healthy == true) }
                TableColumn("Ready") { Badge($0.ready == true ? "READY" : "FAIL", good: $0.ready == true) }
                TableColumn("Status") { Text($0.status ?? "") }
            }
        }
        .padding(24)
    }
}

struct EventsView: View {
    @EnvironmentObject var store: PlatformStore

    var events: [PlatformEvent] {
        Array((store.state?.events ?? []).suffix(80).reversed())
    }

    var body: some View {
        VStack(alignment: .leading) {
            Text("Recent Events")
                .font(.largeTitle.bold())
                .foregroundStyle(.cyan)

            Table(events) {
                TableColumn("Time") {
                    Text(Date(timeIntervalSince1970: $0.ts).formatted())
                }
                TableColumn("Type") {
                    Text($0.type).monospaced()
                }
            }
        }
        .padding(24)
    }
}

struct PluginsView: View {
    @EnvironmentObject var store: PlatformStore

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Plugins")
                .font(.largeTitle.bold())
                .foregroundStyle(.cyan)

            Card(
                title: "Plugin System",
                value: store.plugins?.enabled == true ? "ENABLED" : "DISABLED",
                detail: "\(store.plugins?.count ?? 0) loaded",
                good: store.plugins?.enabled == true
            )

            ForEach(store.plugins?.plugins ?? [], id: \.self) { plugin in
                Text(plugin).monospaced()
            }

            Spacer()
        }
        .padding(24)
    }
}

struct LinksView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Links")
                .font(.largeTitle.bold())
                .foregroundStyle(.cyan)

            Button("Open Web Dashboard") {
                NSWorkspace.shared.open(URL(string: "http://127.0.0.1:9110")!)
            }

            Button("Open API Version") {
                NSWorkspace.shared.open(URL(string: "http://127.0.0.1:9105/api/v1/version")!)
            }

            Button("Open OpenAPI Spec") {
                NSWorkspace.shared.open(URL(string: "http://127.0.0.1:9105/api/v1/openapi.json")!)
            }

            Spacer()
        }
        .padding(24)
    }
}

struct Card: View {
    let title: String
    let value: String
    let detail: String
    let good: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title).foregroundStyle(.secondary).font(.caption)
            Text(value).font(.title2.bold()).foregroundStyle(good ? .green : .red)
            Text(detail).font(.caption).foregroundStyle(.secondary)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.cyan.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }
}

struct Badge: View {
    let text: String
    let good: Bool

    init(_ text: String, good: Bool) {
        self.text = text
        self.good = good
    }

    var body: some View {
        Text(text)
            .font(.caption.bold())
            .foregroundStyle(good ? .green : .red)
    }
}
