#!/usr/bin/env zsh
set -euo pipefail

APPDIR="$HOME/Wonderland/apps/macos/wl-control-center"
ICONSET="$APPDIR/AppIcon.iconset"
ICNS="$APPDIR/AppIcon.icns"

rm -rf "$ICONSET"
mkdir -p "$ICONSET"

python3 - <<'PY'
from pathlib import Path
from PIL import Image, ImageDraw

out = Path.home() / "Wonderland/apps/macos/wl-control-center/AppIcon.iconset"
sizes = {
    "icon_16x16.png": 16,
    "icon_16x16@2x.png": 32,
    "icon_32x32.png": 32,
    "icon_32x32@2x.png": 64,
    "icon_128x128.png": 128,
    "icon_128x128@2x.png": 256,
    "icon_256x256.png": 256,
    "icon_256x256@2x.png": 512,
    "icon_512x512.png": 512,
    "icon_512x512@2x.png": 1024,
}

for name, size in sizes.items():
    img = Image.new("RGBA", (size, size), (5, 7, 10, 255))
    d = ImageDraw.Draw(img)

    pad = max(2, size // 10)
    d.rounded_rectangle(
        [pad, pad, size - pad, size - pad],
        radius=size // 5,
        outline=(0, 229, 255, 255),
        width=max(1, size // 32),
        fill=(5, 7, 10, 255),
    )

    cx = cy = size // 2
    for r in [size * 0.30, size * 0.22, size * 0.14]:
        d.ellipse(
            [cx-r, cy-r, cx+r, cy+r],
            outline=(0, 229, 255, 230),
            width=max(1, size // 48),
        )

    w = size // 9
    d.line(
        [(size*0.28, size*0.34), (size*0.40, size*0.68), (size*0.50, size*0.45), (size*0.60, size*0.68), (size*0.72, size*0.34)],
        fill=(0, 255, 102, 255),
        width=max(2, w),
        joint="curve",
    )

    img.save(out / name)
PY

iconutil -c icns "$ICONSET" -o "$ICNS"

echo "PASS icon $ICNS"
