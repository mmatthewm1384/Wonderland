#!/usr/bin/env zsh
set -euo pipefail

ROOT="$HOME/Wonderland"
BUILDER="$ROOT/apps/macos/wl-control-center/scripts/build-app.zsh"
APP="$HOME/Applications/Wonderland Control Center.app"
OUTDIR="$ROOT/runtime/apps/control-center"
STAMP="$(date +%Y%m%d-%H%M%S)"
DMG="$OUTDIR/Wonderland-Control-Center-$STAMP.dmg"
LATEST="$OUTDIR/Wonderland-Control-Center-latest.dmg"

mkdir -p "$OUTDIR"

"$BUILDER"

rm -f "$DMG"

hdiutil create \
  -volname "Wonderland Control Center" \
  -srcfolder "$APP" \
  -ov \
  -format UDZO \
  "$DMG"

rm -f "$LATEST"
ln -s "$(basename "$DMG")" "$LATEST"

shasum -a 256 "$DMG" > "$DMG.sha256"
cp "$DMG.sha256" "$LATEST.sha256"

echo "PASS dmg $DMG"
echo "PASS latest $LATEST"
