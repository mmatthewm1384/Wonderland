#!/usr/bin/env zsh
set -euo pipefail

ROOT="$HOME/Wonderland"
APPDIR="$ROOT/apps/macos/wl-control-center"
BUILD="$APPDIR/.build/release/wl-control-center"
OUT="$HOME/Applications/Wonderland Control Center.app"

mkdir -p "$HOME/Applications"

cd "$APPDIR"

if [[ ! -f "$APPDIR/AppIcon.icns" ]]; then
  "$APPDIR/scripts/make-icon.zsh"
fi

swift build -c release

rm -rf "$OUT"
mkdir -p "$OUT/Contents/MacOS" "$OUT/Contents/Resources"

cp "$BUILD" "$OUT/Contents/MacOS/Wonderland Control Center"
chmod +x "$OUT/Contents/MacOS/Wonderland Control Center"

cat > "$OUT/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
 "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key>
  <string>Wonderland Control Center</string>
  <key>CFBundleDisplayName</key>
  <string>Wonderland Control Center</string>
  <key>CFBundleIdentifier</key>
  <string>com.wonderland.control-center</string>
  <key>CFBundleVersion</key>
  <string>1</string>
  <key>CFBundleShortVersionString</key>
  <string>1.0.0</string>
  <key>CFBundleExecutable</key>
  <string>Wonderland Control Center</string>
  <key>CFBundleIconFile</key>
  <string>AppIcon</string>
  <key>CFBundlePackageType</key>
  <string>APPL</string>
  <key>LSMinimumSystemVersion</key>
  <string>13.0</string>
  <key>NSHighResolutionCapable</key>
  <true/>
</dict>
</plist>
PLIST

echo "PASS built $OUT"
