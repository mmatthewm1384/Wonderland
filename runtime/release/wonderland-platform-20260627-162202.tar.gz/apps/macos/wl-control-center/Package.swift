// swift-tools-version: 6.3

import PackageDescription

let package = Package(
    name: "wl-control-center",
    platforms: [.macOS(.v13)],
    products: [
        .executable(name: "wl-control-center", targets: ["WLControlCenter"])
    ],
    targets: [
        .executableTarget(name: "WLControlCenter")
    ]
)
