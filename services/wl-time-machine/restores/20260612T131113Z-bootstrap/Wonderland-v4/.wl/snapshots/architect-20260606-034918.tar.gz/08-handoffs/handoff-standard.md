# Handoff Standard

Every Wonderland handoff must include:

- Current state
- Architecture
- Directory structure
- Commands
- Verification
- Recovery
- Rollback
- Future work
