# Wonderland-v4 Overview

Wonderland-v4 is a modular ecosystem for infrastructure, automation, software development, knowledge management, creative systems, and operational governance.

## Principles

- Persistent
- Recoverable
- Auditable
- Secure
- Automated
- Versioned
- Modular

## Primary Knowledge Core

Obsidian

## Primary Interface

wl

## Runtime Doctrine

AI may build Wonderland.

Wonderland must not depend upon AI to run.
