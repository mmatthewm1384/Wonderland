# Wonderland-v4 Roadmap

## Current Initiatives

- Establish Architect scaffold
- Define governance standards
- Build Obsidian knowledge base
- Define wl command interface

## Future Initiatives

- Runtime service registry
- Snapshot and recovery system
- Vault architecture
- Relay architecture
- Governance attestations
