# Wonderland-v4 Standards

## Naming

| Type | Standard |
|---|---|
| Commands | `wl-*` |
| Services | `wl-<service>` |
| Containers | `wl-<service>` |
| Networks | `wonderland-*` |
| Volumes | `wl-<service>-data` |
| Docs | `lowercase-kebab-case.md` |
| Intents | `*.intent.json` |

## Required Sections for Builds

- Structure
- Required files
- Configuration
- Installation
- Verification
- Recovery
- Rollback
