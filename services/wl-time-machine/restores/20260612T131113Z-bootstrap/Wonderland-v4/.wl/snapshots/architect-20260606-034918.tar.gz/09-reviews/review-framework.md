# Review Framework

## Review Categories

- Architecture
- Security
- Operations
- Reliability
- Governance

## Output Format

- Finding
- Severity
- Evidence
- Impact
- Recommendation
- Verification
- Rollback
